# 6amc.pl – Legendarki (Skript)

## Czego potrzebujesz na serwerze
| Plugin | Wersja |
|---|---|
| Paper | 1.21.4 lub nowszy |
| Skript | 2.14+ (pisane pod 2.16.2) |
| FancyHolograms | 2.x (aktualnie 2.12) |

**skript-reflect NIE jest potrzebny.**

## Instalacja
1. Wrzuć `skripty/legendarki.sk` do `plugins/Skript/scripts/`.
2. Resource pack: wrzuć `resourcepack/6amc_legendarki.zip` na hosting z linkiem bezpośrednim
   (GitHub release, mc-packs.net, Dropbox z `?dl=1`), potem w `server.properties`:
   ```
   resource-pack=https://TWOJ-LINK/6amc_legendarki.zip
   resource-pack-sha1=8eb187039db131cc48f4f9e2ec614ac0b67dd03b
   require-resource-pack=true
   ```
3. `/sk reload legendarki`
4. W grze: `/aleg centrum` (stań tam, gdzie ma być środek, np. 0 0 0) → `/aleg postaw`.
   Bez `centrum` skrypt bierze świat `world` i kordy 0 0 0.
5. Uprawnienie dla adminów: `legendarki.admin`.

## Modele 3D
W ręce, na ziemi i na hologramie legendarki mają modele 3D, a w ekwipunku ikonę 2D (tak jest czytelniej). Podgląd: `podglad_3d.png`.

## Legendarki
| ID | Nazwa | Item | CMD | Umiejętność (PPM) | Efekt stały (działa sam) |
|---|---|---|---|---|---|
| `ostrze_switu` | Ostrze Świtu | netherite sword | 6001 | Zryw do przodu (15s) | 20% szansy na leczenie przy trafieniu |
| `topor_burzy` | Topór Burzy | netherite axe | 6002 | Piorun tam, gdzie patrzysz (20s) | 15% szansy na porażenie celu |
| `kosa_zniwiarza` | Kosa Żniwiarza | netherite sword | 6003 | Przyciąga wrogów + uschnięcie (18s) | Wampiryzm 20% |
| `trojzab_otchlani` | Trójząb Otchłani | trident | 6004 | SHIFT+PPM: skok w górę (12s) | Moc przewodu + gracja delfina |
| `mlot_tytana` | Młot Tytana | mace | 6005 | Fala uderzeniowa (20s) | -50% obrażeń od upadku |
| **Słabsze (łatwiejsze)** | | | | | |
| `sztylet_cienia` | Sztylet Cienia | iron sword | 6006 | Niewidzialność + szybkość II na 3s (25s) | 15% szansy na spowolnienie celu |
| `luk_zefira` | Łuk Zefira | bow | 6007 | SHIFT+LPM: odskok do tyłu (10s) | Strzały lecą 40% szybciej |
| `kilof_krasnoluda` | Kilof Krasnoluda | diamond pickaxe | 6008 | Pośpiech III na 20s (60s) | 12% szansy na podwójny urobek z rud |
| `kostur_mrozu` | Kostur Mrozu | golden hoe | 6009 | Lodowy pocisk: 2❤ + spowolnienie II (2s) | Trafienie wręcz spowalnia (nie orze ziemi) |
| `kusza_lowcy` | Kusza Łowcy | crossbow | 6010 | SHIFT+LPM: podświetla wszystko w promieniu 20 (30s) | Trafiony bełtem cel świeci 5s |
| **Mityczna** | | | | | |
| `pozeracz_dusz` | Pożeracz Dusz | netherite sword | 6011 | od poz. III: Krzyk Dusz (14s) | rośnie za zabójstwa, patrz niżej |

### Pożeracz Dusz (ulepsza się za kille)
- Każdy egzemplarz ma własne **ID** w opisie i liczy **dusze**: mob **+1**, gracz **+10** (tego samego gracza liczy raz na 5 min, żeby nie farmić kolegi).
- Po każdym zabójstwie miecz w ręce się przebudowuje: w opisie widać poziom, pasek postępu i odblokowane ulepszenia. Awans na poziom = tytuł, dźwięk i ogłoszenie na czacie.

| Poziom | Dusze | Co daje |
|---|---|---|
| I | 0 | Ostrość V, Grabież III |
| II | 25 | Ostrość VI + wampiryzm 10% |
| III | 75 | Ostrość VII + **PPM: Krzyk Dusz** (fala sonic boom, 6❤ na linii 12 bloków) |
| IV | 150 | Ostrość VIII, zaklęty ogień II + Siła I w ręce |
| V | 300 | Ostrość X, grabież V, szybkość I, wampiryzm 20%, +3❤ za zabójstwo, krzyk 9❤ |

- Admin: `/aleg dusze` (Pożeracz w ręce) pokazuje dusze, `/aleg dusze <ile>` je ustawia.
- Stoi na **środku**, na podeście z pozłacanego czarnokamienia.

## Wygląd (v5)
- **Nazwy i opisy z gradientem** (MiniMessage, działa w samym Skripcie 2.16 bez dodatków). Każdy opis ma ten sam układ: cytat, ✦ umiejętność z klawiszem i odnowieniem, ❖ efekt stały, ranga (✦ limitowana / ✧ zwykła / ☠ mityczna).
- **Pożeracz Dusz**: nazwa zmienia kolor z poziomem, pasek postępu z procentami, lista ulepszeń z progami dusz.
- **Czat**: prefix `ʟᴇɢᴇɴᴅᴀʀᴋɪ »`, ogłoszenie wykucia w ramce z gradientem, tytuły z gradientem.
- **Action bar**: nazwa umiejętności w kolorach legendarki, odnowienie z paskiem postępu.
- **Hologramy FancyHolograms**: nowe linie z rangą, stanem i podpowiedzią `[PPM]`.
- **GUI**: tytuły z gradientem, nagłówki rang, głowa gracza z jego kolekcją (`x/11`).
- **Spawn**: lodestony stoją na podestach (limitowane: rzeźbiony polerowany czarnokamień, zwykłe: rzeźbiony łupek, mityczna: pozłacany czarnokamień), wokół kręci się krąg run z cząsteczek, a Pożeracz świeci czerwoną poświatą. Wyłączysz to w `options` (`podesty`, `krag_run`). Podestów nie da się zniszczyć.
- Po aktualizacji: `/sk reload legendarki`, potem `/aleg postaw` (żeby pojawiły się podesty).

## Animacje hologramów (v6)
- **Item**: płynny obrót z lekkim kołysaniem (przechył), unoszenie się i „oddychanie” skali.
- **Pokaz co ~15 s**: item podskakuje, robi pełny obrót, a z lodestona rozchodzi się kolorowy pierścień. Każdy lodestone w innym momencie. Kliknięcie lodestona też odpala pokaz.
- **Gdy ktoś podejdzie** (5 kratek): item zwalnia, rośnie i unosi się wyżej, nazwa się powiększa, lecą cząsteczki zaklinania, a gracz słyszy cichy dzwonek i widzi podpowiedź na action barze.
- **Nazwa**: przesuwający się gradient i migoczące gwiazdki ✦ ✧ ⋆.
- **Cząsteczki w kolorach legendarki**: kolorowa spirala z lodestona do itemu, obracająca się aureola na lodestonie, orbity w przechylonej płaszczyźnie. Mityczna ma dodatkowo pulsujący pierścień dusz i czerwoną poświatę.
- **Wyprzedana**: item przechylony, prawie stoi, szara nazwa z dopiskiem, popiół.
- **Wykucie**: item unosi się i rozkręca, energia zbiega się do niego, potem wybuch światła, pierścienie i powolne opadanie na miejsce.
- Podgląd animacji wykucia: `/aleg pokaz <id|wszystkie>`.
- Wydajność na serwerze testowym: ok. 4 ms/tick przy 11 animowanych lodestonach.

## Stock (ile sztuk)
- Każda legendarka ma **stock**, czyli ile sztuk może w ogóle powstać. Domyślnie jest 1 (`domyslny_stock` w `options`).
- Jeden gracz może mieć **tylko 1 sztukę** danej legendarki.
- Kiedy stock się skończy, w stole zamiast legendarki pojawia się bariera „Wyprzedane!”, a hologram robi się szary i zwalnia.
- `/aleg stock` – lista, `/aleg stock <id|wszystkie> <ile>` – ustaw, `/aleg stock <id|wszystkie> dodaj <ile>` – dodaj.
  W `/aleg gui`: SHIFT+PPM = +1, Q = −1.
- Ze starej wersji skrypt sam przenosi, kto co już wykraftował.

## Receptury (domyślne)
Sloty: 1 2 3 / 4 5 6 / 7 8 9 (puste = nic). Zmienisz je w `/aleg receptura <id>` (GUI).

| Legendarka | Receptura |
|---|---|
| Ostrze Świtu | słonecznik, blok złota, słonecznik / blaze rod, **diamentowy miecz**, blaze rod / słonecznik, blok złota, słonecznik |
| Topór Burzy | piorunochron, blok diamentu, piorunochron / blok miedzi, **diamentowa siekiera**, blok miedzi / –, odłamek ametystu, – |
| Kosa Żniwiarza | blok kości, perła endu, blok kości / piasek dusz, **diamentowa motyka**, piasek dusz / płaczący obsydian, –, płaczący obsydian |
| Trójząb Otchłani | muszla łodzika, diament, muszla łodzika / odłamek pryzmarynu, **serce morza**, odłamek pryzmarynu / –, latarnia morska, – |
| Młot Tytana | blok żelaza, blok diamentu, blok żelaza / –, **breeze rod**, – / –, breeze rod, – |
| Sztylet Cienia | worek atramentu, sztabka żelaza, worek atramentu / pióro, **żelazny miecz**, pióro |
| Łuk Zefira | pióro, sztabka złota, pióro / nić, **łuk**, nić / –, 16 strzał, – |
| Kilof Krasnoluda | sztabka złota, szmaragd, sztabka złota / blok redstone, **diamentowy kilof**, blok redstone |
| Kostur Mrozu | blok śniegu, diament, blok śniegu / 8 śnieżek, **złota motyka**, 8 śnieżek |
| Kusza Łowcy | nić, blok żelaza, nić / 8 strzał, **kusza**, 8 strzał |
| Pożeracz Dusz | sztabka netherytu, czaszka witherowego szkieletu, sztabka netherytu / blok diamentu, **netherytowy miecz**, blok diamentu / echo shard, totem nieśmiertelności, echo shard |

## Komendy
**Gracze**
- `/legendarki` – GUI z listą legendarek i statusem
- `/legendarki <id>` – receptura konkretnej legendarki
- PPM na lodestone na spawnie – receptura w GUI

**Admin** (`/adminlegendarki`, skróty `/aleg` i `/alegendarki`)
- `/aleg centrum` – środek spawnu = twoja pozycja
- `/aleg postaw` / `/aleg usun` – stawia albo usuwa 11 lodestonów z hologramami (10 w kole, Pożeracz na środku). Po aktualizacji do v4 **wpisz `/aleg postaw` jeszcze raz**, bo stare lodestony same się usuną i staną nowe. Po postawieniu zejdź ze środka, bo tam staje środkowy lodestone.
- `/aleg ustaw <1-11> <id>` – która legendarka stoi na danym lodestonie
- `/aleg ustaw <id>` – to samo, patrząc na lodestone
- `/aleg hologram item <1-11> <id|reka|reset>` – item na hologramie (`reka` = item z ręki)
- `/aleg hologram item <id|reka|reset>` – to samo, patrząc na lodestone
- `/aleg hologram odswiez` / `usun` – odtwarza albo usuwa napisy
- `/aleg receptura <id>` – edytor receptury w GUI (liczy się też ilość itemów w slocie)
- `/aleg receptura <id> reset` – przywraca domyślną recepturę
- `/aleg daj <id> [gracz]` – daje kopię (nie liczy się do stocku)
- `/aleg stock ...` – patrz wyżej
- `/aleg odbierz <id> <gracz>` – zwalnia sztukę gracza (wraca do stocku)
- `/aleg reset <id|wszystko>` – czyści wszystkich posiadaczy
- `/aleg info <id>`, `/aleg lista`, `/aleg gui` (panel: LPM daj, PPM edytuj, SHIFT+PPM +1 stock, Q −1 stock, SHIFT+LPM reset)
- `/aleg dusze [ile]` – dusze Pożeracza w ręce
- `/aleg pokaz <id|wszystkie>` – podgląd animacji wykucia
- `/aleg tp`, `/aleg przeladuj`

## Ustawienia (na górze pliku, `options:`)
`swiat`, `promien` (promień koła 10 lodestonów, domyślnie 7), `wysokosc_itemu`, `wysokosc_tekstu`, `wysokosc_nazwy`, `skala_itemu`, `skala_nazwy`, `domyslny_stock`, `wersja_receptur` (podbij, żeby wymusić domyślne receptury).

## Jak działają hologramy (i animacje)
- **Animowana nazwa** (na samej górze) to text display ze Skripta, z gradientem, który ciągle się przesuwa. Jak legendarka jest wyprzedana, nazwa robi się szara.
- **Napis info** pod nią to hologram FancyHolograms (`leg6amc_tekst_1..5`): ile zostało, kto ostatni ją zdobył i „PPM = receptura”.
  Tworzy go admin przez `/aleg postaw` albo `/aleg hologram odswiez`, bo FancyHolograms pozwala tworzyć hologramy tylko graczowi. Potem skrypt sam go aktualizuje z konsoli.
- **Item 3D** to item display ze Skripta: płynnie się obraca, unosi i opada, zawsze jest jasny (także w nocy).
  Wokół krążą cząsteczki w kolorze legendarki, a z lodestona lecą cząsteczki zaklinania.
- Po wykraftowaniu: piorun (tylko efekt, bez obrażeń), wybuch cząsteczek i przez 3 sekundy szybki obrót.
- Skrypt sam pilnuje, żeby nad każdym lodestonem był dokładnie 1 item i 1 nazwa, także po restarcie.

## Animacje w GUI
- **Receptura**: składniki wskakują po kolei, każdy z coraz wyższym dźwiękiem, a na końcu pojawia się legendarka.
  Przy każdym składniku jest napisane, czy go masz w ekwipunku (✔/✘).
- Wokół ramki biegną dwa „węże” w kolorze legendarki (szare, gdy wyprzedana). Strzałka ➜ miga.
- **Lista legendarek** (5 rzędów): u góry mocne, niżej słabsze, na dole mityczna. Pojawiają się po kolei, a ramka mieni się na złoto.

## Tekstury (CC0, można używać bez podawania autora)
- Ostrze Świtu, Pożeracz Dusz (przekolorowany) – *Fantasy Swords 16x16* by Ishtar Pixels – https://opengameart.org/content/fantasy-swords-16x16-pack-10
- Pozostałe – *16x16 Weapon RPG Icons* (przekolorowane pod serwer) – https://opengameart.org/content/16x16-weapon-rpg-icons

## Nowości v7
- **Podświetlenie po spojrzeniu** – gdy patrzysz na legendarkę (do 10 bloków), zaczyna świecić w swoim kolorze. Robi się też większa, szybciej się kręci i unosi, a wokół niej wybucha pierścień cząsteczek. Nazwa dostaje ramkę » « i dopisek „[kliknij] zobacz recepturę”, a na pasku akcji pojawia się podpowiedź.
- **Klik z 10 bloków** – PPM lub LPM otwiera recepturę (opcja `zasieg_klik`). Na czas patrzenia skrypt zwiększa graczowi zasięg interakcji, a potem go przywraca. Uderzenia z dalszej odległości niż 4 bloki są wtedy blokowane, więc nie da się tego użyć do bicia z daleka.
- **Mega efekt na czacie po wykuciu** – baner pojawia się linijka po linijce z rosnącym dźwiękiem. Po najechaniu na nazwę widać pełny opis, a kliknięcie otwiera recepturę. Do tego tytuł na ekranie dla wszystkich, dźwięki, 3 fajerwerki i cząsteczki totemu nad graczem.
- Poprawka: przy wyprzedanej legendarce nie wyświetla się już dosłowny tekst „<newline>”.
- Poprawka paczki: buzdygan i inne modele w pierwszej osobie mają normalny rozmiar. **Nowy sha1 paczki: `8eb187039db131cc48f4f9e2ec614ac0b67dd03b`** – podmień go w server.properties.

## Nowości v8
### Region wokół koła legendarek
W promieniu **20 kratek** od środka koła (cały słup, każda wysokość):
- **brak mobów**: nie spawnują się, a te, które wejdą na teren, znikają z obłoczkiem. Oswojone zwierzaki graczy zostają.
- **brak TNT i wybuchów**: TNT gaśnie, wybuchy (też tuż przy granicy) nie niszczą bloków i nie ranią graczy.
- **brak niszczenia i budowania**: wiadra, ogień, tłoki, endermany, ramki, stojaki na zbroję, obrazy, zdzieranie kory, ścieżki, mączka kostna itp.
- **PvP działa** normalnie.
- Przy granicy widać łuk z cząsteczek, a przy wejściu i wyjściu pokazuje się komunikat na pasku akcji.

Dodatkowo: obrazy i ramki nie dają się zniszczyć, nie da się zdeptać pola uprawnego, a kotwic odrodzenia nie da się ładować do 8 kratek za granicą (w zwykłym świecie wybuchają). Fajerwerki z kuszy w PvP dalej ranią.

Komendy admina:
- `/aleg region`: status
- `/aleg region pokaz`: pokazuje granicę przez 10 s
- `/aleg region bypass`: włącza/wyłącza możliwość budowania dla ciebie
- `/aleg region promien <5-200>`
- `/aleg region wlacz|wylacz`

Region opiera się na środku ustawionym przez `/aleg centrum`. Domyślny promień zmienisz w opcji `region_promien`.

### Lepsze i animowane tekstury
- Modele 3D mają teraz prawdziwe materiały z tekstur CC0 (słoje drewna, owijki, kuty metal, złoto, klejnoty) zamiast jednolitych kolorów.
- Animacje: połysk przesuwa się po ostrzach i złocie, klejnoty pulsują i iskrzą. Ikony w ekwipunku mają przesuwający się błysk.
- **Nowy sha1 paczki: `8eb187039db131cc48f4f9e2ec614ac0b67dd03b`**. Podmień go w server.properties i wgraj nowy zip.

### Źródła (`_zrodla/`)
Jeśli chcesz przebudować paczkę, uruchom po kolei `gen.py`, `gen2.py` i `gen3_animacje.py`. Wynik jest zawsze taki sam, a poprawione rozmiary modeli w ręce zostają zachowane. `render_tex.py --gif` robi podgląd.

## Nowości v8.1
- **Admin ma automatyczny bypass regionu.** Każdy z uprawnieniem `legendarki.admin` (albo OP) może na terenie niszczyć i budować. Zwykli gracze nadal nie mogą. `/aleg region bypass` wyłącza bypass tylko dla ciebie (np. do testów) i włącza go z powrotem.
- **Naprawione `/aleg postaw <legendarka>` i `/aleg ustaw <legendarka>` bez numeru.** Legendarka trafia na lodestone, na który patrzysz (na hologram, lodestone albo podest). Jeśli na żaden nie patrzysz, trafia na najbliższy w promieniu 8 kratek.
  - Działają skróty nazw: `kosa`, `pozeracz`, `luk`, `Kostur_Mrozu`...
  - Działają też `/aleg ustaw 5 luk` i `/aleg ustaw luk 5`.
  - `/aleg postaw` bez argumentu dalej stawia całe koło.
- **`/aleg twardyreset`** przywraca wszystko do ustawień domyślnych. Trzeba go potwierdzić: `/aleg twardyreset potwierdz` w ciągu 30 s. Resetuje:
  - stock, liczniki i posiadaczy
  - receptury
  - przypisanie legendarek do lodestonów i itemy hologramów
  - dusze Pożeracza
  - ustawienia regionu
  
  Lodestony i środek zostają na miejscu. Legendarek, które gracze już mają, reset nie zabiera.

## Nowości v8.2
- **Legendarka na WŁASNYM lodestonie.** Postaw lodestone gdziekolwiek, podejdź i celuj w niego z bliska (celownik na bloku), a potem wpisz `/aleg postaw kosa`. Lodestone dostaje numer 12, 13 itd., hologram, obracający się item, podświetlanie i klikanie.
  - `/aleg usun tutaj` (patrząc na niego) odpina taki lodestone. Blok zostaje.
  - `/aleg postaw` bez argumentu przestawia tylko koło (1-11), a twoje własne lodestony zostają.
  - Uwaga: region chroni tylko teren wokół koła. Własny lodestone daleko od koła nie jest chroniony przez region, ale sam blok lodestona dalej jest chroniony przed zniszczeniem.
- **Animacja napisów w 20 FPS**, odświeżana co tick. Liczy się tylko dla lodestonów, które ktoś widzi (40 kratek), więc serwer tego nie odczuwa. Nowe efekty:
  - płynny gradient, przez który przechodzi biały błysk
  - migoczące gwiazdki i drugie podkreślenie, które płynie w przeciwną stronę
  - „maszyna do pisania”: gdy podchodzisz, nazwa wypisuje się litera po literze z kursorem
  - po najechaniu wzrokiem strzałki » « wjeżdżają w nazwę, a „[kliknij]” pulsuje
  - Pożeracz Dusz: czaszki biją jak serce (podwójne uderzenie), a nazwa ma krwawy połysk
  - wyprzedana: szary połysk i przygasający napis „✖ wyprzedana ✖”

## Poprawki v8.3
- **Hologram własnego lodestona był przesunięty o pół kratki** (w bok i w górę). Teraz jest dokładnie na środku. Lodestony postawione wcześniej naprawiają się same: po `/sk reload` pierwszy admin, który wejdzie na serwer albo wpisze dowolną `/aleg`, dostanie komunikat „Wyśrodkowano hologramy”.
- **`/aleg hologram item <legendarka>`** patrząc na zwykły lodestone też robi z niego lodestone legendarki (tak jak `/aleg postaw`).
- Item i napis pojawiają się od razu po komendzie, bez sekundowego opóźnienia.

## Nowości v9 - EVENTY i EVENTÓWKI

**Eventówki** to 5 nowych przedmiotów, których nie da się wykraftować. Zdobywa się je tylko na eventach. Każda ma własną animowaną teksturę (CMD 6101-6105).

| Eventówka | Baza | Umiejętność |
|---|---|---|
| Berło Fajerwerków | blaze_rod | PPM: salwa 6 fajerwerków wokół gracza (nie ranią), cd 8 s |
| Miecz Karnawału | golden_sword (Ostrość IV) | cios sypie konfetti; PPM **Karnawałowy Wir**: odpycha w promieniu 4 kratek + Szybkość II, cd 20 s |
| Sierp Żniw | iron_hoe | PPM na dojrzałe plony: zbiera 5x5 i od razu sadzi (pszenica, marchew, ziemniaki, buraki), cd 2 s |
| Bumerang Wichru | stick | PPM: leci ~12 kratek, kręci się, rani wszystko po drodze i wraca, cd 3 s |
| Młotek Imprezowy | wooden_shovel (Odrzut II) | uderzenie podrzuca trafionego w górę, raz na 1,5 s |

**Event ZRZUT:**
- Na 30 s przed zrzutem pojawia się boss bar z odliczaniem, a nad miejscem zrzutu słup światła.
- Potem z nieba spada skrzynia (płynna animacja) i ląduje z falą uderzeniową.
- **Pierwszy gracz, który ją kliknie**, dostaje losową eventówkę. Skrzynia znika po 3 minutach.

**Event BOSS - Strażnik Legendarek:**
- Olbrzymi szkielet witherowy z 150 ❤ i netherytowym ekwipunkiem.
- Atakuje co ~5 s na trzy sposoby: fala uderzeniowa, deszcz ognia (czerwone kręgi pod graczami), przyciąganie.
- Nie odchodzi dalej niż 22 kratki od areny i znika po 10 minutach.
- Nagrody wg zadanych obrażeń:
  - 1. miejsce: 2 eventówki
  - 2. i 3. miejsce: po 1 eventówce
  - pozostali walczący: 5 poziomów XP
- Boss może walczyć na chronionym spawnie (region go nie usuwa).

**Automatyczne eventy:** startują co 45 minut (opcja `event_auto_minut`), jeśli online są min. 3 osoby (`event_min_graczy`). Losowanie: zrzut 70%, boss 30%.

**Dodatkowe efekty:**
- Trzymana legendarka lub eventówka ma wokół gracza aurę z cząsteczek.
- Zabójstwo gracza legendarką/eventówką daje efekt i komunikat na czacie w promieniu 60 kratek.

**Komendy:**
- `/legendarki eventowki`: GUI z eventówkami i opisem, jak je zdobyć. Admin może kliknąć przedmiot, żeby dostać kopię.
- `/aleg event`: pokazuje, co teraz trwa, i listę podkomend.
- `/aleg event zrzut [tutaj]` / `/aleg event boss [tutaj]`: bez `tutaj` event startuje przy spawnie (wymaga `/aleg centrum`).
- `/aleg event stop`: przerywa event bez nagród.
- `/aleg event auto <minuty|off>`: ustawia albo wyłącza automatyczne eventy.
- `/aleg eventowka <id> [gracz]`: daje eventówkę (wystarczy skrót id, np. `berlo`, `bumerang`).
- `/aleg eventowki`: GUI eventówek.

**Resource pack:** zaktualizowany, podmień go na serwerze. Nowy sha1 to `8eb187039db131cc48f4f9e2ec614ac0b67dd03b`. Ikony eventówek pochodzą z zestawu CC0 „16x16 Weapon RPG Icons” (OpenGameArt), są przekolorowane i animowane skryptem `_zrodla/gen4_eventowki.py`.
