import json, os, random
from PIL import Image
RP='/home/user/6amc_legendarki/resourcepack/6amc_legendarki'
random.seed(6)

# --- paleta: 16 próbek 16x16 w teksturze 64x64 (UV 4x4 na próbkę) ---
def swatch_tex(cols, path):
    im=Image.new('RGBA',(64,64),(0,0,0,0)); px=im.load()
    for idx,c in enumerate(cols):
        if c is None: continue
        sx=(idx%4)*16; sy=(idx//4)*16
        for y in range(16):
            for x in range(16):
                n=random.randint(-9,9)
                shade = 18 if (y<2 or x<2) else (-22 if (y>13 or x>13) else 0)
                px[sx+x,sy+y]=tuple(max(0,min(255,c[i]+n+shade)) for i in range(3))+(255,)
    im.save(path)
def uv(i): return [(i%4)*4,(i//4)*4,(i%4)*4+4,(i//4)*4+4]
def el(a,b,s,rot=None):
    e={"from":a,"to":b,"faces":{f:{"uv":uv(s),"texture":"#0"} for f in ["north","south","east","west","up","down"]}}
    if rot: e["rotation"]=rot
    return e
def disp(big=False):
    s=0.8 if not big else 0.75
    return {
     "thirdperson_righthand":{"rotation":[0,-90,10],"translation":[0,4,0.5],"scale":[s,s,s]},
     "thirdperson_lefthand":{"rotation":[0,90,-10],"translation":[0,4,0.5],"scale":[s,s,s]},
     "firstperson_righthand":{"rotation":[0,-90,-20],"translation":[1.13,3.2,1.13],"scale":[0.62,0.62,0.62]},
     "firstperson_lefthand":{"rotation":[0,90,20],"translation":[1.13,3.2,1.13],"scale":[0.62,0.62,0.62]},
     "gui":{"rotation":[0,0,-45],"scale":[0.72,0.72,0.72]},
     "ground":{"translation":[0,2,0],"scale":[0.45,0.45,0.45]},
     "fixed":{"rotation":[0,0,-45],"scale":[0.8,0.8,0.8]},
     "head":{"translation":[0,10,0]}}
def save(name, cols, els):
    if not os.path.exists(f'{RP}/assets/legendarki/textures/item/{name}_3d.png.mcmeta'):
        swatch_tex(cols, f'{RP}/assets/legendarki/textures/item/{name}_3d.png')
    m={"textures":{"0":f"legendarki:item/{name}_3d","particle":f"legendarki:item/{name}"},"elements":els,"display":disp()}
    # v7+: zachowaj poprawione ustawienia display (rozmiar w 1. i 3. osobie) z istniejącego modelu
    _old=f'{RP}/assets/legendarki/models/item/{name}_3d.json'
    if os.path.exists(_old): m["display"]=json.load(open(_old)).get("display",m["display"])
    json.dump(m,open(f'{RP}/assets/legendarki/models/item/{name}_3d.json','w'),indent=1)
    # ikona 2D do ekwipunku
    json.dump({"parent":"minecraft:item/handheld","textures":{"layer0":f"legendarki:item/{name}"}},open(f'{RP}/assets/legendarki/models/item/{name}.json','w'),indent=1)

# 0 skóra ciemna,1 skóra,2 drewno,3 metal ciemny,4 metal,5 metal jasny,6 akcent,7 akcent ciemny,8 klejnot,9 klejnot jasny
# ---------------- OSTRZE ŚWITU ----------------
C=[(70,30,30),(120,55,45),(90,60,40),(150,160,175),(205,215,225),(245,250,255),(235,180,60),(170,110,30),(220,60,120),(255,140,190)]+[None]*6
save('ostrze_switu',C,[
 el([7,-3,7],[9,4,9],1),
 el([6.9,-1,6.9],[9.1,-0.3,9.1],0), el([6.9,1.5,6.9],[9.1,2.2,9.1],0),
 el([6.5,-4.5,6.5],[9.5,-3,9.5],6),
 el([7.25,-5.25,7.25],[8.75,-4.5,8.75],8),
 el([3,4,6.5],[13,5.5,9.5],6),
 el([2,4.5,7],[3,7,9],7), el([13,4.5,7],[14,7,9],7),
 el([7,3.75,6],[9,5.75,10],8),
 el([6.5,5.5,7.5],[9.5,20,8.5],4),
 el([6.2,5.5,7.7],[6.5,19.5,8.3],5), el([9.5,5.5,7.7],[9.8,19.5,8.3],5),
 el([7.6,6,7.35],[8.4,17,8.65],6),
 el([7,20,7.6],[9,22,8.4],4), el([7.5,22,7.7],[8.5,23.5,8.3],5),
])
# ---------------- TOPÓR BURZY ----------------
C=[(30,25,25),(60,40,30),(95,65,40),(35,60,110),(60,120,210),(170,225,255),(210,170,70),(130,95,40),(80,230,255),(220,250,255)]+[None]*6
save('topor_burzy',C,[
 el([7.25,-4,7.25],[8.75,20,8.75],2),
 el([7,-1,7],[9,0,9],0), el([7,1.5,7],[9,2.5,9],0), el([7,4,7],[9,5,9],0),
 el([7,-5,7],[9,-4,9],6),
 el([6.5,14,6.5],[9.5,19,9.5],3),
 el([9.5,12.5,7.5],[12.5,20.5,8.5],4), el([12.5,11.5,7.6],[14,21.5,8.4],5),
 el([3.5,12.5,7.5],[6.5,20.5,8.5],4), el([2,11.5,7.6],[3.5,21.5,8.4],5),
 el([7.5,19,7.5],[8.5,23,8.5],5),
 el([7,15.5,6],[9,17.5,10],8), el([7.4,15.9,5.7],[8.6,17.1,10.3],9),
 el([6.4,13.5,6.4],[9.6,14,9.6],6), el([6.4,19,6.4],[9.6,19.5,9.6],6),
])
# ---------------- KOSA ŻNIWIARZA ----------------
C=[(25,15,30),(55,35,45),(60,40,35),(45,20,70),(110,50,170),(215,170,255),(160,150,170),(90,80,100),(70,255,220),(190,255,245)]+[None]*6
save('kosa_zniwiarza',C,[
 el([7.25,-4,7.25],[8.75,21,8.75],2),
 el([7,0,7],[9,1,9],0), el([7,3,7],[9,4,9],0), el([7,10,7],[9,11,9],0),
 el([7,-5,7],[9,-4,9],7),
 el([6.75,19.5,6.75],[9.25,22.5,9.25],3),
 el([7,20,6.5],[9,22,9.5],8),
 el([2.5,19.5,7.6],[7,21.5,8.4],4),
 el([-0.5,18.5,7.6],[2.5,20.5,8.4],4),
 el([-2.5,16.5,7.6],[-0.5,19,8.4],4),
 el([-3.5,14,7.6],[-1.5,16.5,8.4],4),
 el([-4,12,7.7],[-2.5,14,8.3],5),
 el([2.5,19,7.7],[7,19.5,8.3],5), el([-0.5,18,7.7],[2.5,18.5,8.3],5),
 el([-1.5,16,7.7],[-0.5,16.5,8.3],5), el([-1.5,14,7.7],[-1,16,8.3],5),
 el([7.5,22.5,7.5],[8.5,24,8.5],6),
])
# ---------------- TRÓJZĄB OTCHŁANI ----------------
C=[(10,40,45),(20,80,85),(30,110,110),(10,90,100),(40,190,180),(200,255,245),(230,200,110),(150,120,50),(40,120,255),(170,220,255)]+[None]*6
save('trojzab_otchlani',C,[
 el([7.4,-4,7.4],[8.6,17,8.6],2),
 el([7.2,-1,7.2],[8.8,0,8.8],6), el([7.2,6,7.2],[8.8,7,8.8],6),
 el([7.1,-5,7.1],[8.9,-4,8.9],6),
 el([4,17,7.25],[12,18.25,8.75],3),
 el([7.25,18,7.25],[8.75,24,8.75],4), el([7.5,24,7.5],[8.5,26.5,8.5],5),
 el([4,18,7.4],[5.2,22.5,8.6],4), el([4.1,22.5,7.5],[5.1,24.5,8.5],5),
 el([10.8,18,7.4],[12,22.5,8.6],4), el([10.9,22.5,7.5],[11.9,24.5,8.5],5),
 el([3.3,20,7.6],[4,21.5,8.4],5), el([12,20,7.6],[12.7,21.5,8.4],5),
 el([7,16.25,6.75],[9,18.75,9.25],8), el([7.4,16.65,6.5],[8.6,18.35,9.5],9),
])
# ---------------- MŁOT TYTANA ----------------
C=[(35,25,25),(70,45,40),(80,55,40),(90,30,20),(185,70,30),(255,190,90),(240,200,90),(150,110,40),(255,120,20),(255,220,120)]+[None]*6
save('mlot_tytana',C,[
 el([7.25,-4,7.25],[8.75,15,8.75],2),
 el([7,-1,7],[9,0,9],1), el([7,1,7],[9,2,9],1), el([7,3,7],[9,4,9],1),
 el([6.75,-5.5,6.75],[9.25,-4,9.25],6),
 el([3,15,5],[13,21,11],4),
 el([2,15.5,5.5],[3,20.5,10.5],5), el([13,15.5,5.5],[14,20.5,10.5],5),
 el([4.5,14.5,4.5],[5.5,21.5,11.5],3), el([10.5,14.5,4.5],[11.5,21.5,11.5],3),
 el([7,17,4.5],[9,19,5],8), el([7,17,11],[9,19,11.5],8),
 el([7.5,21,7.5],[8.5,23,8.5],6),
 el([6.5,14,6.5],[9.5,15,9.5],7),
])

# --- definicje itemów 1.21.4+ : ikona 2D w GUI, 3D w ręce / hologramie ---
def M(m): return {"type":"minecraft:model","model":m}
def leg(mid): return {"type":"minecraft:select","property":"minecraft:display_context",
  "cases":[{"when":["gui"],"model":M(f"legendarki:item/{mid}")}],"fallback":M(f"legendarki:item/{mid}_3d")}
def rd(fallback, entries):
    e=[]
    for cmd,mid in entries:
        e.append({"threshold":cmd,"model":leg(mid)}); e.append({"threshold":cmd+1,"model":fallback})
    return {"model":{"type":"minecraft:range_dispatch","property":"minecraft:custom_model_data","index":0,"fallback":fallback,"entries":e}}
w=lambda n,d: json.dump(d,open(f'{RP}/assets/minecraft/items/{n}.json','w'),indent=1)
w('netherite_sword',rd(M("minecraft:item/netherite_sword"),[(6001,'ostrze_switu'),(6003,'kosa_zniwiarza')]))
w('netherite_axe',rd(M("minecraft:item/netherite_axe"),[(6002,'topor_burzy')]))
w('mace',rd(M("minecraft:item/mace"),[(6005,'mlot_tytana')]))
tr={"type":"minecraft:select","property":"minecraft:display_context","cases":[{"when":["gui","ground","fixed"],"model":M("minecraft:item/trident")}],
 "fallback":{"type":"minecraft:condition","property":"minecraft:using_item",
   "on_false":{"type":"minecraft:special","base":"minecraft:item/trident_in_hand","model":{"type":"minecraft:trident"}},
   "on_true":{"type":"minecraft:special","base":"minecraft:item/trident_throwing","model":{"type":"minecraft:trident"}}}}
w('trident',rd(tr,[(6004,'trojzab_otchlani')]))
json.dump({"pack":{"description":"§6§l6amc.pl §7- Legendarki 3D","pack_format":46,"supported_formats":{"min_inclusive":46,"max_inclusive":1000},"min_format":46,"max_format":1000}},open(f'{RP}/pack.mcmeta','w'),indent=1,ensure_ascii=False)
print("ok")
