# Podgląd modeli 3D z teksturami (software renderer, painter's algorithm).
# python3 render_tex.py  -> podglad_3d.png + podglad_anim.gif
import json, math, sys
from PIL import Image, ImageDraw
RP = '/home/user/6amc_legendarki/resourcepack/6amc_legendarki/assets/legendarki'
OUT = '/home/user/6amc_legendarki/'
ids = ['ostrze_switu', 'topor_burzy', 'kosa_zniwiarza', 'trojzab_otchlani', 'mlot_tytana', 'sztylet_cienia',
       'luk_zefira', 'kilof_krasnoluda', 'kostur_mrozu', 'kusza_lowcy', 'pozeracz_dusz']
N = 4  # podział ściany na 4x4 texeli na jednostkę uv (1 uv = 4 px)

def rotm(yaw, pitch):
    cy, sy, cp, sp = math.cos(yaw), math.sin(yaw), math.cos(pitch), math.sin(pitch)
    def f(p):
        x, y, z = p[0] - 8, p[1] - 10, p[2] - 8
        x, z = x * cy - z * sy, x * sy + z * cy
        y, z = y * cp - z * sp, y * sp + z * cp
        return x, y, z
    return f

FACES = {  # normal, 4 corners as (from/to selector) with s,t axes
    'north': ((0, 0, -1), lambda a, b, s, t: (b[0] - (b[0] - a[0]) * s, b[1] - (b[1] - a[1]) * t, a[2])),
    'south': ((0, 0, 1), lambda a, b, s, t: (a[0] + (b[0] - a[0]) * s, b[1] - (b[1] - a[1]) * t, b[2])),
    'west': ((-1, 0, 0), lambda a, b, s, t: (a[0], b[1] - (b[1] - a[1]) * t, a[2] + (b[2] - a[2]) * s)),
    'east': ((1, 0, 0), lambda a, b, s, t: (b[0], b[1] - (b[1] - a[1]) * t, b[2] - (b[2] - a[2]) * s)),
    'up': ((0, 1, 0), lambda a, b, s, t: (a[0] + (b[0] - a[0]) * s, b[1], a[2] + (b[2] - a[2]) * t)),
    'down': ((0, -1, 0), lambda a, b, s, t: (a[0] + (b[0] - a[0]) * s, a[1], b[2] - (b[2] - a[2]) * t)),
}
LIGHT = {'up': 1.0, 'down': 0.5, 'north': 0.8, 'south': 0.8, 'east': 0.6, 'west': 0.6}

def render(mid, frame, yaw, size=220, pitch=-0.35):
    m = json.load(open(f'{RP}/models/item/{mid}_3d.json'))
    tex = Image.open(f'{RP}/textures/item/{mid}_3d.png').convert('RGB')
    nfr = tex.height // 64
    fr = frame % nfr
    R = rotm(yaw, pitch)
    polys = []
    for e in m['elements']:
        a, b = e['from'], e['to']
        for fn, (nrm, P) in FACES.items():
            n = R((nrm[0] + 8, nrm[1] + 10, nrm[2] + 8))
            if n[2] > -0.01: continue  # tył (kamera patrzy w +z)
            u = e['faces'][fn]['uv']
            for i in range(N * 4):
                for j in range(N * 4):
                    s0, s1, t0, t1 = i / (N * 4), (i + 1) / (N * 4), j / (N * 4), (j + 1) / (N * 4)
                    pts = [R(P(a, b, s, t)) for s, t in ((s0, t0), (s1, t0), (s1, t1), (s0, t1))]
                    tx = int(u[0] * 4 + (u[2] - u[0]) * 4 * (i + 0.5) / (N * 4))
                    ty = int(u[1] * 4 + (u[3] - u[1]) * 4 * (j + 0.5) / (N * 4)) + fr * 64
                    c = tex.getpixel((min(63, tx), ty))
                    l = LIGHT[fn]
                    depth = sum(p[2] for p in pts) / 4
                    polys.append((depth, pts, tuple(int(v * l) for v in c)))
    polys.sort(key=lambda q: -q[0])
    im = Image.new('RGB', (size, size), (38, 38, 42))
    d = ImageDraw.Draw(im)
    sc = size / 36
    for _, pts, c in polys:
        d.polygon([(size / 2 + p[0] * sc, size * 0.55 - p[1] * sc) for p in pts], fill=c)
    return im

if __name__ == '__main__':
    sheet = Image.new('RGB', (6 * 220, 2 * 240), (38, 38, 42))
    dd = ImageDraw.Draw(sheet)
    for k, i in enumerate(ids):
        im = render(i, 3, 0.6)
        x, y = (k % 6) * 220, (k // 6) * 240
        sheet.paste(im, (x, y + 20)); dd.text((x + 8, y + 4), i, fill='white')
    # ikony 2D (pierwsza klatka) w prawym dolnym rogu
    for k, i in enumerate(ids):
        ic = Image.open(f'{RP}/textures/item/{i}.png').convert('RGBA').crop((0, 0, 16, 16)).resize((32, 32), 0)
        sheet.paste(ic, (5 * 220 + 8 + (k % 5) * 40, 260 + (k // 5) * 40), ic)
    sheet.save(OUT + 'podglad_3d.png')
    if '--gif' in sys.argv:
        fr = []
        S = 170
        for f in range(20):
            row = Image.new('RGB', (6 * S, 2 * S), (38, 38, 42))
            for k, i in enumerate(ids):
                row.paste(render(i, f, 0.6 + f * 2 * math.pi / 20, S), ((k % 6) * S, (k // 6) * S))
            fr.append(row)
        fr[0].save(OUT + 'podglad_anim.gif', save_all=True, append_images=fr[1:], duration=100, loop=0)
    print('ok')
