from PIL import Image
import colorsys
RP='/home/user/6amc_legendarki/resourcepack/6amc_legendarki/assets/legendarki/textures/item/'
W='/tmp/tx/w/16x16 Weapons RPG Icons/iron-weapons.png'
F='/tmp/tx/f/Fantasy Swords 16X16 pack 1.0/Sword-Pack-1.png'
def cell(path,c,r): return Image.open(path).convert('RGBA').crop((c*16,r*16,c*16+16,r*16+16))
def grad(pal,t):
    t=max(0,min(1,t)); n=len(pal)-1; i=min(int(t*n),n-1); f=t*n-i
    a,b=pal[i],pal[i+1]; return tuple(int(a[k]+(b[k]-a[k])*f) for k in range(3))
def recolor(im, main, acc=None, gem=None):
    px=im.load(); out=im.copy(); po=out.load()
    for y in range(16):
        for x in range(16):
            r,g,b,a=px[x,y]
            if a==0: continue
            h,l,s=colorsys.rgb_to_hls(r/255,g/255,b/255)
            if l<0.12: continue  # obrys zostaje
            if s>0.35 and acc is None and 0.03<h<0.17:
                continue
            if s>0.35 and acc is not None and (h<0.17 or h>0.9) and not (gem and (h>0.8 or h<0.02) and s>0.5 and r>150 and g<120):
                po[x,y]=grad(acc,l)+(a,)
            elif gem and s>0.4 and (h>0.8 or h<0.03 or 0.2<h<0.45):
                po[x,y]=grad(gem,l)+(a,)
            else:
                po[x,y]=grad(main,l)+(a,)
    return out
save=lambda im,n: im.save(RP+n+'.png')
# Sztylet Cienia - fioletowo-czarne ostrze
save(recolor(cell(W,9,2),[(20,10,30),(70,45,105),(160,130,210),(235,220,255)],[(30,20,30),(80,55,80),(150,110,150)]),'sztylet_cienia')
# Łuk Zefira - miętowo-białe drewno
save(recolor(cell(W,17,12),[(40,70,70),(140,200,190),(240,255,250)],[(30,70,60),(90,170,150),(200,250,235)]),'luk_zefira')
# Kilof Krasnoluda - głowica diamentowo-turkusowa, trzonek zostaje drewniany
save(recolor(cell(W,14,12),[(10,50,60),(50,170,175),(210,255,250)],None),'kilof_krasnoluda')
# Kostur Mrozu - lodowy
save(recolor(cell(W,19,6),[(30,60,110),(120,180,235),(235,250,255)],[(25,60,120),(100,170,240),(225,245,255)]),'kostur_mrozu')
# Kusza Łowcy - leśna zieleń + ciemne drewno
save(recolor(cell(W,20,8),[(30,30,30),(110,110,105),(210,210,200)],None,[(20,50,20),(70,140,50),(170,230,120)]),'kusza_lowcy')
# Pożeracz Dusz - karmazynowe ostrze, ciemne złoto
save(recolor(cell(F,3,1),[(20,0,6),(95,0,22),(185,20,45),(255,95,95)],[(60,30,0),(170,110,20),(255,210,90)],[(90,0,120),(200,40,255),(255,180,255)]),'pozeracz_dusz')
print('ok')
