import json, os, random
from PIL import Image
RP='/home/user/6amc_legendarki/resourcepack/6amc_legendarki'
random.seed(66)

# --- paleta: 16 próbek 16x16 w teksturze 64x64 (UV 4x4 na próbkę) ---
def swatch_tex(cols, path):
    im=Image.new('RGBA',(64,64),(0,0,0,0)); px=im.load()
    for idx,c in enumerate(cols):
        if c is None: continue
        sx=(idx%4)*16; sy=(idx//4)*16
        for y in range(16):
            for x in range(16):
                n=random.randint(-9,9)
                shade = 18 if (y<2 or x<2) else (-22 if (y>13 or x>13) else 0)
                px[sx+x,sy+y]=tuple(max(0,min(255,c[i]+n+shade)) for i in range(3))+(255,)
    im.save(path)
def uv(i): return [(i%4)*4,(i//4)*4,(i%4)*4+4,(i//4)*4+4]
def el(a,b,s,rot=None):
    e={"from":a,"to":b,"faces":{f:{"uv":uv(s),"texture":"#0"} for f in ["north","south","east","west","up","down"]}}
    if rot: e["rotation"]=rot
    return e
def disp(big=False):
    s=0.8 if not big else 0.75
    return {
     "thirdperson_righthand":{"rotation":[0,-90,10],"translation":[0,4,0.5],"scale":[s,s,s]},
     "thirdperson_lefthand":{"rotation":[0,90,-10],"translation":[0,4,0.5],"scale":[s,s,s]},
     "firstperson_righthand":{"rotation":[0,-90,-20],"translation":[1.13,3.2,1.13],"scale":[0.62,0.62,0.62]},
     "firstperson_lefthand":{"rotation":[0,90,20],"translation":[1.13,3.2,1.13],"scale":[0.62,0.62,0.62]},
     "gui":{"rotation":[0,0,-45],"scale":[0.72,0.72,0.72]},
     "ground":{"translation":[0,2,0],"scale":[0.45,0.45,0.45]},
     "fixed":{"rotation":[0,0,-45],"scale":[0.8,0.8,0.8]},
     "head":{"translation":[0,10,0]}}
def save(name, cols, els):
    if not os.path.exists(f'{RP}/assets/legendarki/textures/item/{name}_3d.png.mcmeta'):
        swatch_tex(cols, f'{RP}/assets/legendarki/textures/item/{name}_3d.png')
    m={"textures":{"0":f"legendarki:item/{name}_3d","particle":f"legendarki:item/{name}"},"elements":els,"display":disp()}
    # v7+: zachowaj poprawione ustawienia display (rozmiar w 1. i 3. osobie) z istniejącego modelu
    _old=f'{RP}/assets/legendarki/models/item/{name}_3d.json'
    if os.path.exists(_old): m["display"]=json.load(open(_old)).get("display",m["display"])
    json.dump(m,open(f'{RP}/assets/legendarki/models/item/{name}_3d.json','w'),indent=1)
    # ikona 2D do ekwipunku
    json.dump({"parent":"minecraft:item/handheld","textures":{"layer0":f"legendarki:item/{name}"}},open(f'{RP}/assets/legendarki/models/item/{name}.json','w'),indent=1)


# ---------------- SZTYLET CIENIA (krótki) ----------------
C=[(20,15,25),(45,35,55),(60,45,40),(40,30,65),(110,85,160),(200,180,245),(90,70,110),(50,40,60),(150,60,255),(220,170,255)]+[None]*6
save('sztylet_cienia',C,[
 el([7.25,-3,7.25],[8.75,3,8.75],1),
 el([7,-1,7],[9,-0.4,9],0), el([7,1.2,7],[9,1.8,9],0),
 el([6.8,-4.2,6.8],[9.2,-3,9.2],6),
 el([4.5,3,7],[11.5,4.2,9],6), el([4,3.2,7.3],[4.8,5,8.7],7), el([11.2,3.2,7.3],[12,5,8.7],7),
 el([7.3,3.3,6.6],[8.7,4,9.4],8),
 el([7,4.2,7.6],[9,13,8.4],4), el([6.7,4.2,7.75],[7,12.5,8.25],5), el([9,4.2,7.75],[9.3,12.5,8.25],5),
 el([7.4,13,7.7],[8.6,15,8.3],5),
])
# ---------------- ŁUK ZEFIRA ----------------
C=[(30,50,50),(60,110,100),(100,170,155),(170,225,210),(235,255,250),(255,255,255),(210,190,120),(140,120,70),(120,255,210),(220,255,245)]+[None]*6
save('luk_zefira',C,[
 el([6.5,5,7],[8.5,11,9],1), el([6.3,6.5,6.8],[8.7,9.5,9.2],6),
 el([7,11,7.25],[8.5,14,8.75],2), el([7.5,14,7.3],[9,17,8.7],2), el([8.5,17,7.4],[10,19,8.6],3), el([9.8,19,7.5],[11.2,20.3,8.5],4),
 el([7,2,7.25],[8.5,5,8.75],2), el([7.5,-1,7.3],[9,2,8.7],2), el([8.5,-3,7.4],[10,-1,8.6],3), el([9.8,-4.3,7.5],[11.2,-3,8.5],4),
 el([11,-3.5,7.9],[11.4,19.5,8.1],5),
 el([7.2,7.5,6.6],[8,8.5,9.4],8),
])
# ---------------- KILOF KRASNOLUDA ----------------
C=[(30,20,15),(70,45,30),(110,75,45),(20,70,75),(60,170,175),(200,255,250),(200,160,70),(130,95,40),(90,255,200),(220,255,240)]+[None]*6
save('kilof_krasnoluda',C,[
 el([7.25,-4,7.25],[8.75,17,8.75],2),
 el([7,-1,7],[9,0,9],1), el([7,2,7],[9,3,9],1),
 el([7,-5,7],[9,-4,9],6),
 el([6.5,15.5,6.5],[9.5,18.5,9.5],7),
 el([3,16,7.2],[13,18,8.8],4),
 el([1.5,14.5,7.4],[3.5,17,8.6],4), el([12.5,14.5,7.4],[14.5,17,8.6],4),
 el([0.5,12.5,7.6],[2,15,8.4],5), el([14,12.5,7.6],[15.5,15,8.4],5),
 el([7.2,16.3,6.8],[8.8,17.9,9.2],8),
])
# ---------------- KOSTUR MROZU ----------------
C=[(20,40,70),(50,90,140),(90,70,50),(60,110,170),(130,190,240),(230,250,255),(200,220,240),(120,150,190),(120,230,255),(240,255,255)]+[None]*6
save('kostur_mrozu',C,[
 el([7.3,-5,7.3],[8.7,19,8.7],3),
 el([7.1,-1,7.1],[8.9,0,8.9],6), el([7.1,5,7.1],[8.9,6,8.9],6), el([7.1,11,7.1],[8.9,12,8.9],6),
 el([7,-6,7],[9,-5,9],7),
 el([6.5,18.5,6.5],[9.5,20,9.5],4),
 el([5.5,19.5,7.5],[6.5,24,8.5],5), el([9.5,19.5,7.5],[10.5,24,8.5],5),
 el([7.5,19.5,5.5],[8.5,24,6.5],5), el([7.5,19.5,9.5],[8.5,24,10.5],5),
 el([6.5,20.5,6.5],[9.5,25.5,9.5],8,{"angle":45,"axis":"y","origin":[8,23,8]}),
 el([7.2,25,7.2],[8.8,27,8.8],9,{"angle":45,"axis":"y","origin":[8,26,8]}),
])
# ---------------- KUSZA ŁOWCY ----------------
C=[(25,20,15),(70,50,30),(110,80,45),(40,40,40),(120,120,115),(210,210,200),(40,90,35),(25,60,20),(110,190,70),(230,230,210)]+[None]*6
save('kusza_lowcy',C,[
 el([7,-4,7],[9,13,9],2), el([6.8,-4.5,6.8],[9.2,-2,9.2],1),
 el([7.3,3,6],[8.7,5,7],3),
 el([7.4,4,7.4],[8.6,15,8.6],4),
 el([1,12,7.3],[15,13.5,8.7],6), el([0,11,7.4],[2,12.5,8.6],7), el([14,11,7.4],[16,12.5,8.6],7),
 el([1,9.7,7.9],[15,10.1,8.1],9),
 el([7.5,15,7.5],[8.5,17,8.5],5),
 el([6.6,11.6,6.6],[9.4,13.9,9.4],8),
])
# ---------------- POŻERACZ DUSZ (najlepszy) ----------------
C=[(15,5,10),(45,15,25),(70,20,30),(60,0,15),(150,15,40),(255,90,100),(200,150,40),(120,80,20),(190,40,255),(255,170,255)]+[None]*6
save('pozeracz_dusz',C,[
 el([7.2,-3.5,7.2],[8.8,4,8.8],1),
 el([7,-2,7],[9,-1.3,9],0), el([7,0.5,7],[9,1.2,9],0), el([7,2.7,7],[9,3.4,9],0),
 el([6.5,-5.5,6.5],[9.5,-3.5,9.5],6), el([7.2,-6.2,7.2],[8.8,-5.5,8.8],8),
 el([2.5,4,6.5],[13.5,5.8,9.5],6),
 el([1,5,7],[2.5,8.5,9],7), el([13.5,5,7],[15,8.5,9],7),
 el([0.3,8,7.3],[1.5,10,8.7],6), el([14.5,8,7.3],[15.7,10,8.7],6),
 el([6.8,3.6,5.8],[9.2,6.2,10.2],8), el([7.3,4.1,5.5],[8.7,5.7,10.5],9),
 el([5.5,5.8,7.3],[10.5,23,8.7],4),
 el([5,6,7.5],[5.5,22,8.5],5), el([10.5,6,7.5],[11,22,8.5],5),
 el([7.5,6.5,7.1],[8.5,21,8.9],8),
 el([6.3,23,7.4],[9.7,25.5,8.6],4), el([7.2,25.5,7.6],[8.8,27.5,8.4],5),
])

def M(m): return {"type":"minecraft:model","model":m}
def leg(mid): return {"type":"minecraft:select","property":"minecraft:display_context",
  "cases":[{"when":["gui"],"model":M(f"legendarki:item/{mid}")}],"fallback":M(f"legendarki:item/{mid}_3d")}
def rd(fallback, entries):
    e=[]
    for cmd,mid in sorted(entries):
        e.append({"threshold":cmd,"model":leg(mid)}); e.append({"threshold":cmd+1,"model":fallback})
    return {"model":{"type":"minecraft:range_dispatch","property":"minecraft:custom_model_data","index":0,"fallback":fallback,"entries":e}}
w=lambda n,d: json.dump(d,open(f'{RP}/assets/minecraft/items/{n}.json','w'),indent=1)
van=lambda n: json.load(open(os.path.join(os.path.dirname(os.path.abspath(__file__)),'vanilla',f'van_{n}.json')))["model"]
w('netherite_sword',rd(M("minecraft:item/netherite_sword"),[(6001,'ostrze_switu'),(6003,'kosa_zniwiarza'),(6011,'pozeracz_dusz')]))
w('iron_sword',rd(van('iron_sword'),[(6006,'sztylet_cienia')]))
w('bow',rd(van('bow'),[(6007,'luk_zefira')]))
w('diamond_pickaxe',rd(van('diamond_pickaxe'),[(6008,'kilof_krasnoluda')]))
w('golden_hoe',rd(van('golden_hoe'),[(6009,'kostur_mrozu')]))
w('crossbow',rd(van('crossbow'),[(6010,'kusza_lowcy')]))
print("ok2")
