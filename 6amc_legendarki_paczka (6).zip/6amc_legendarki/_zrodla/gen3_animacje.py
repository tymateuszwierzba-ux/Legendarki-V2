# v8: lepsze + animowane tekstury.
# - tekstury 3D: każda próbka (swatch) 16x16 bazuje na prawdziwej teksturze CC0
#   ("16x16 Block Texture Set", ARoachIFoundOnMyPillow, opengameart.org),
#   przemapowanej jasnością na paletę legendarki + fazowane krawędzie,
# - animacja: przesuwający się połysk po metalu, pulsujące i iskrzące klejnoty,
# - ikony 2D (ekwipunek): animowany błysk przechodzący po ostrzu.
# Uruchamiaj wielokrotnie - bazowe ikony 2D są w _zrodla/ikony_base/.
import re, os, math, random, json, shutil, zlib
from PIL import Image

RP = '/home/user/6amc_legendarki/resourcepack/6amc_legendarki/assets/legendarki/textures/item/'
SRC = os.path.dirname(os.path.abspath(__file__))
BLK = os.path.join(SRC, 'cc0_bloki')          # kopie użytych tekstur CC0
BASE2D = os.path.join(SRC, 'ikony_base')
FR = 20            # klatek animacji
FT = 2             # ticków na klatkę -> cykl 2 s

# --- palety wyciągnięte z gen.py / gen2.py ---
PAL = {}
for f in ('gen.py', 'gen2.py'):
    s = open(os.path.join(SRC, f), encoding='utf-8').read()
    for m in re.finditer(r"^C=(\[.*?\])\+\[None\]\*6\s*\nsave\('(\w+)'", s, re.M):
        PAL[m.group(2)] = eval(m.group(1))
assert len(PAL) == 11, PAL.keys()

def lum_map(name, rot=0, contrast=1.0):
    im = Image.open(os.path.join(BLK, name + '.png')).convert('RGB')
    if rot: im = im.rotate(rot)
    px = im.load()
    L = [[(0.3 * px[x, y][0] + 0.59 * px[x, y][1] + 0.11 * px[x, y][2]) / 255 for x in range(16)] for y in range(16)]
    flat = [v for r in L for v in r]
    mean = sum(flat) / len(flat)
    sd = (sum((v - mean) ** 2 for v in flat) / len(flat)) ** 0.5 or 1
    return [[max(0, min(1, 0.5 + (L[y][x] - mean) / sd * 0.17 * contrast)) for x in range(16)] for y in range(16)]

# rola każdej próbki: (tekstura bazowa, obrót, kontrast, materiał)
ROLE = {
    0: ('schist', 90, 1.1, 'skora'),        # owijka ciemna
    1: ('oak_log_side', 90, 1.0, 'skora'),  # owijka (poprzeczne pasy)
    2: ('oak_log_side', 0, 1.0, 'drewno'),  # trzonek - słoje wzdłuż
    3: ('basalt', 0, 0.8, 'metal'),
    4: ('marble', 0, 0.55, 'metal'),
    5: ('marble_bricks', 0, 0.35, 'metal'),
    6: ('rhyolite', 0, 0.6, 'zloto'),
    7: ('granite', 0, 0.8, 'zloto'),
    8: ('amethyst', 0, 1.0, 'klejnot'),
    9: ('ice_glacier', 0, 0.9, 'klejnot'),
}

def mix(a, b, t): return tuple(a[i] + (b[i] - a[i]) * t for i in range(3))
def clamp(c): return tuple(max(0, min(255, int(round(v)))) for v in c)

def shade(c, v):
    # v 0..1: ciemne -> 45% koloru, środek -> kolor, jasne -> w stronę bieli
    if v < 0.5: return mix(tuple(x * 0.45 for x in c), c, v * 2)
    return mix(c, (255, 255, 255), (v - 0.5) * 0.7)

def swatch(c, idx, frame, rnd):
    tex, rot, k, mat = ROLE[idx]
    L = lum_map(tex, rot, k)
    out = [[None] * 16 for _ in range(16)]
    t = frame / FR
    for y in range(16):
        for x in range(16):
            v = L[y][x]
            # fazowanie krawędzi - daje "bryłę"
            if x == 0 or y == 0: v += 0.16
            elif x == 1 or y == 1: v += 0.06
            if x == 15 or y == 15: v -= 0.2
            elif x == 14 or y == 14: v -= 0.08
            col = shade(c, max(0, min(1, v)))
            if mat in ('metal', 'zloto'):
                # połysk: ukośny pas przejeżdża w pierwszych 60% cyklu
                p = -8 + (t / 0.6) * 40
                d = abs((x + y) - p)
                if t < 0.6 and d < 3.5:
                    col = mix(col, (255, 255, 255), (1 - d / 3.5) * (0.55 if mat == 'metal' else 0.4))
            elif mat == 'klejnot':
                pul = 0.5 + 0.5 * math.sin(t * 2 * math.pi)
                col = mix(tuple(v2 * 0.82 for v2 in col), mix(col, (255, 255, 255), 0.25), pul)
            out[y][x] = clamp(col)
    if mat == 'klejnot':
        # iskry: kilka pikseli rozbłyska w każdej klatce
        for _ in range(3):
            sx, sy = rnd.randint(2, 13), rnd.randint(2, 13)
            out[sy][sx] = (255, 255, 255)
            for dx, dy in ((1, 0), (-1, 0), (0, 1), (0, -1)):
                out[sy + dy][sx + dx] = clamp(mix(out[sy + dy][sx + dx], (255, 255, 255), 0.5))
    return out

def mcmeta(path):
    json.dump({"animation": {"frametime": FT, "interpolate": True}}, open(path + '.mcmeta', 'w'), indent=1)

for name, cols in PAL.items():
    im = Image.new('RGBA', (64, 64 * FR), (0, 0, 0, 0))
    px = im.load()
    for fr in range(FR):
        rnd = random.Random(zlib.crc32(f"{name}:{fr}".encode()))
        for idx, c in enumerate(cols):
            if c is None: continue
            sw = swatch(c, idx, fr, rnd)
            sx, sy = (idx % 4) * 16, (idx // 4) * 16 + fr * 64
            for y in range(16):
                for x in range(16):
                    px[sx + x, sy + y] = sw[y][x] + (255,)
    p = RP + name + '_3d.png'
    im.save(p); mcmeta(p)

# --- ikony 2D: animowany błysk ---
os.makedirs(BASE2D, exist_ok=True)
for name in PAL:
    b = os.path.join(BASE2D, name + '.png')
    if not os.path.exists(b): shutil.copy(RP + name + '.png', b)
    base = Image.open(b).convert('RGBA'); bp = base.load()
    im = Image.new('RGBA', (16, 16 * FR), (0, 0, 0, 0)); px = im.load()
    for fr in range(FR):
        t = fr / FR
        p = -6 + (t / 0.55) * 40      # pas od lewego dołu do prawej góry
        for y in range(16):
            for x in range(16):
                r, g, bb, a = bp[x, y]
                col = (r, g, bb)
                lum = (0.3 * r + 0.59 * g + 0.11 * bb) / 255
                if a and lum > 0.12 and t < 0.55:
                    d = abs((x + (15 - y)) - p)
                    if d < 2.5: col = mix(col, (255, 255, 255), (1 - d / 2.5) * 0.7)
                px[x, y + fr * 16] = clamp(col) + (a,)
    p = RP + name + '.png'
    im.save(p); mcmeta(p)
print('ok', len(PAL))
