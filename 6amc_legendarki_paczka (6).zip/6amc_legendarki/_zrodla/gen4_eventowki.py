# Eventówki: ikony z CC0 "16x16 Weapon RPG Icons" (OpenGameArt), przekolorowane + animowany połysk
import json, os, math
from PIL import Image
BASE=os.path.dirname(os.path.abspath(__file__))
SRC=os.path.join(BASE,'ikony_ev','gold-weapons.png')
PACK=os.path.join(BASE,'..','resourcepack','6amc_legendarki','assets')
FR=20; FT=2
EV={ # id: (vanilla, cmd, (kol,wiersz), paleta ciemny->jasny)
 'berlo_fajerwerkow':('blaze_rod',6101,(4,15),[(90,20,70),(214,60,160),(255,150,200),(255,230,140),(255,255,235)]),
 'miecz_karnawalu':('golden_sword',6102,(5,5),[(70,20,80),(210,60,140),(255,150,120),(255,225,120),(255,255,240)]),
 'sierp_zniw':('iron_hoe',6103,(15,11),[(40,70,20),(90,158,47),(182,255,107),(255,211,107),(255,250,220)]),
 'bumerang':('stick',6104,(13,0),[(60,30,90),(60,110,220),(107,184,255),(255,179,71),(255,240,200)]),
 'mlotek_imprezowy':('wooden_shovel',6105,(22,12),[(70,10,90),(200,40,200),(255,110,240),(255,225,77),(255,255,230)]),
}
def lerp(a,b,t): return tuple(int(round(a[i]+(b[i]-a[i])*t)) for i in range(3))
def pal(p,v):
    v=max(0,min(1,v))*(len(p)-1); i=min(int(v),len(p)-2); return lerp(p[i],p[i+1],v-i)
sheet=Image.open(SRC).convert('RGBA')
for id_,(van,cmd,(c,r),p) in EV.items():
    ic=sheet.crop((c*16,r*16,c*16+16,r*16+16))
    px=ic.load()
    lums=[ (0.3*px[x,y][0]+0.59*px[x,y][1]+0.11*px[x,y][2]) for y in range(16) for x in range(16) if px[x,y][3]>0 and sum(px[x,y][:3])>60]
    lo,hi=min(lums),max(lums)
    strip=Image.new('RGBA',(16,16*FR))
    for f in range(FR):
        ph=f/FR
        band=-8+ph*40           # ukośny pas połysku przesuwa się przez ikonę
        for y in range(16):
            for x in range(16):
                R,G,B,A=px[x,y]
                if A==0: continue
                if R+G+B<=60:    # czarny kontur zostaje
                    strip.putpixel((x,y+16*f),(20,12,24,A)); continue
                l=((0.3*R+0.59*G+0.11*B)-lo)/max(1,hi-lo)
                # delikatna tęczowa fala po palecie + pas światła
                l2=l*0.85+0.08*math.sin(2*math.pi*(ph+(x+y)/20))
                col=pal(p,l2)
                d=abs((x+(15-y))-band)
                if d<2.2:
                    k=(1-d/2.2)*0.75
                    col=lerp(col,(255,255,255),k)
                strip.putpixel((x,y+16*f),col+(A,))
    tdir=os.path.join(PACK,'legendarki','textures','item'); os.makedirs(tdir,exist_ok=True)
    tp=os.path.join(tdir,f'ev_{id_}.png'); strip.save(tp)
    json.dump({'animation':{'frametime':FT,'interpolate':True}},open(tp+'.mcmeta','w'),indent=1)
    mdir=os.path.join(PACK,'legendarki','models','item'); os.makedirs(mdir,exist_ok=True)
    json.dump({'parent':'minecraft:item/handheld','textures':{'layer0':f'legendarki:item/ev_{id_}'}},open(os.path.join(mdir,f'ev_{id_}.json'),'w'),indent=1)
    # definicja przedmiotu: range_dispatch po CMD (vanilla, gdy brak CMD)
    idir=os.path.join(PACK,'minecraft','items'); ip=os.path.join(idir,f'{van}.json')
    fb={'type':'minecraft:model','model':f'minecraft:item/{van}'}
    d={'model':{'type':'minecraft:range_dispatch','property':'minecraft:custom_model_data','index':0,'fallback':fb,
        'entries':[{'threshold':cmd,'model':{'type':'minecraft:model','model':f'legendarki:item/ev_{id_}'}},{'threshold':cmd+1,'model':fb}]}}
    json.dump(d,open(ip,'w'),indent=1)
    print('ok',id_)
