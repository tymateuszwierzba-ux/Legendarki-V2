import json, numpy as np, matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt
from mpl_toolkits.mplot3d.art3d import Poly3DCollection
from PIL import Image
RP='/home/user/6amc_legendarki/resourcepack/6amc_legendarki/assets/legendarki'
ids=['ostrze_switu','topor_burzy','kosa_zniwiarza','trojzab_otchlani','mlot_tytana','sztylet_cienia','luk_zefira','kilof_krasnoluda','kostur_mrozu','kusza_lowcy','pozeracz_dusz']
fig=plt.figure(figsize=(24,12),facecolor='#303030')
for k,i in enumerate(ids):
    m=json.load(open(f'{RP}/models/item/{i}_3d.json')); tex=Image.open(f'{RP}/textures/item/{i}_3d.png').convert('RGB')
    ax=fig.add_subplot(2,6,k+1,projection='3d'); ax.set_facecolor('#303030')
    for e in m['elements']:
        (x0,y0,z0),(x1,y1,z1)=e['from'],e['to']; u=e['faces']['north']['uv']
        c=np.array(tex.getpixel((int(u[0]*4+8),int(u[1]*4+8))))/255
        V=[[x0,z0,y0],[x1,z0,y0],[x1,z1,y0],[x0,z1,y0],[x0,z0,y1],[x1,z0,y1],[x1,z1,y1],[x0,z1,y1]]
        F=[[0,1,2,3],[4,5,6,7],[0,1,5,4],[2,3,7,6],[1,2,6,5],[0,3,7,4]]
        sh=[0.6,1.0,0.8,0.8,0.9,0.7]
        ax.add_collection3d(Poly3DCollection([[V[j] for j in f] for f in F],facecolors=[np.clip(c*s,0,1) for s in sh],edgecolors=(0,0,0,0.5),linewidths=0.3))
    ax.set_xlim(-6,22);ax.set_ylim(-6,22);ax.set_zlim(-6,27);ax.set_box_aspect((28,28,33));ax.axis('off');ax.view_init(15,-60)
    ax.set_title(i,color='w')
plt.tight_layout();plt.savefig('/home/user/6amc_legendarki/podglad_3d.png',dpi=70,facecolor='#303030')
