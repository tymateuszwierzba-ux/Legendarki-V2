const mineflayer=require('/var/tmp/t/bot/node_modules/mineflayer'); const fs=require('fs'); const {Vec3}=require('/var/tmp/t/bot/node_modules/vec3');
const con=c=>fs.writeFileSync('/var/tmp/t/srv/in',c+'\n');
const sl=ms=>new Promise(r=>setTimeout(r,ms));
function flat(j){if(typeof j==='string')return j;let s=j.text||'';if(j[''])s+=j[''];if(j.extra)for(const e of j.extra)s+=flat(e);return s}
const bot=mineflayer.createBot({host:'127.0.0.1',port:25599,username:'Tester',version:'1.21.11'});
bot.on('message',m=>{const t=m.toString(); if(t.trim())console.log('CHAT:',t.slice(0,200))});
bot.on('windowOpen',w=>console.log('WINDOW:',JSON.stringify(w.title).slice(0,120),'slots',w.slots.filter(Boolean).map(s=>s.name).join(',').slice(0,200)));
function inv(){return bot.inventory.items().map(i=>i.name+':'+JSON.stringify(i.components?.find?.(c=>c.type==='custom_model_data')?.data||'')).join(' | ')}
async function hold(name){const it=bot.inventory.items().find(i=>i.name===name); if(!it){console.log('BRAK',name);return false} await bot.equip(it,'hand'); await sl(300); return true}
bot.once('spawn',async()=>{
 try{
 await sl(1500);
 con('gamemode creative Tester'); con('tp Tester 0 -60 0'); await sl(1000);
 bot.chat('/aleg centrum'); await sl(1500);
 for(const id of ['berlo','miecz','sierp','bumerang','mlotek']){bot.chat('/aleg eventowka '+id); await sl(400)}
 await sl(800); console.log('INV:',inv());
 // teren poza regionem
 con('tp Tester 100 -60 100 0 0'); await sl(1500);
 // berło
 await hold('blaze_rod'); bot.activateItem(); await sl(2500);
 con('execute as Tester run say fireworks=') ;
 // bumerang vs zombie
 con('summon zombie 100 -60 106 {NoAI:1b,Tags:["cel"],Health:20f}'); await sl(800);
 await bot.lookAt(new Vec3(100,-58.5,106)); await hold('stick'); bot.activateItem(); await sl(3500);
 con('data get entity @e[tag=cel,limit=1] Health'); await sl(500);
 // młotek
 con('tp @e[tag=cel] 100 -60 102'); await sl(600);
 await hold('wooden_shovel'); const z=bot.nearestEntity(e=>e.name==='zombie'); console.log('zombie',!!z);
 bot.attack(z); await sl(150); con('data get entity @e[tag=cel,limit=1] Motion'); await sl(1500);
 // miecz wir
 await hold('golden_sword'); con('tp @e[tag=cel] 100 -60 102'); await sl(500); bot.activateItem(); await sl(200); con('data get entity @e[tag=cel,limit=1] Motion'); await sl(1500);
 con('kill @e[tag=cel]');
 // sierp
 con('fill 97 -61 110 103 -61 116 farmland'); con('fill 97 -60 110 103 -60 116 wheat[age=7]'); con('setblock 100 -60 113 carrots[age=7]'); await sl(1000);
 con('tp Tester 100 -60 108'); await sl(800);
 await hold('iron_hoe'); const b=bot.blockAt(new Vec3(100,-60,111)); console.log('blok',b&&b.name,b&&b.getProperties());
 await bot.lookAt(new Vec3(100.5,-59.8,111.5)); await bot.activateBlock(b); await sl(1000);
 for(const p of [[100,111],[102,113],[100,113],[99,110],[97,110],[103,116]]){const bb=bot.blockAt(new Vec3(p[0],-60,p[1])); console.log('po',p,bb.name,JSON.stringify(bb.getProperties()))}
 con('execute store result score @p dummy run kill @e[type=item,distance=..10]'); 
 const items=Object.values(bot.entities).filter(e=>e.name==='item').length; console.log('itemy na ziemi',items);
 // GUI
 bot.chat('/legendarki eventowki'); await sl(1500); bot.closeWindow(bot.currentWindow||bot.inventory); await sl(500);
 bot.chat('/aleg event'); await sl(800);
 // ZRZUT
 con('tp Tester 150 -60 150'); await sl(1000);
 bot.chat('/aleg event zrzut tutaj'); await sl(2000);
 bot.chat('/aleg event boss tutaj'); await sl(500);
 con('tp Tester 152 -60 150'); await sl(33000);
 const before=bot.inventory.items().length;
 const inter=bot.nearestEntity(e=>e.name==='interaction'); console.log('interaction',!!inter, inter&&inter.position);
 if(inter){bot.activateEntity(inter); await sl(1500)}
 console.log('eq przed/po',before,bot.inventory.items().length);
 // BOSS
 bot.chat('/aleg event boss tutaj'); await sl(12000);
 con('data get entity @e[tag=leg_boss,limit=1] Health'); con('data get entity @e[tag=leg_boss,limit=1] attributes'); await sl(1000);
 await sl(6000);
 con('damage @e[tag=leg_boss,limit=1] 120 minecraft:player_attack by Tester'); await sl(1500);
 con('data get entity @e[tag=leg_boss,limit=1] Health'); await sl(4000);
 con('damage @e[tag=leg_boss,limit=1] 500 minecraft:player_attack by Tester'); await sl(4000);
 console.log('INV END:',inv());
 }catch(e){console.log('ERR',e)}
 bot.quit(); process.exit(0);
});
